import React, { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { AnimatePresence, motion } from 'framer-motion';

const Preloader = ({ onAnimationComplete }) => {
  const [counter, setCounter] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const counterRef = useRef(null);
  const preloaderRef = useRef(null);

  useEffect(() => {
    const target = { value: 0 };
    gsap.to(target, {
      value: 100,
      duration: 2.5,
      ease: 'power3.inOut',
      onUpdate: () => {
        setCounter(Math.round(target.value));
      },
      onComplete: () => {
        gsap.to(counterRef.current, {
          opacity: 0,
          duration: 0.3,
          onComplete: () => {
            setIsComplete(true);
          },
        });
      },
    });
  }, []);

  useEffect(() => {
    if (isComplete) {
      const tl = gsap.timeline({
        onComplete: onAnimationComplete,
      });
      tl.to(preloaderRef.current, {
        clipPath: 'polygon(0% 0%, 100% 0%, 100% 0%, 0% 0%)',
        duration: 1.2,
        ease: 'power4.inOut',
      });
    }
  }, [isComplete, onAnimationComplete]);

  return (
    <div
      ref={preloaderRef}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-gray-900 text-white"
      style={{ clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)' }}
    >
      <div className="flex items-center space-x-4">
        <img
          src="https://storage.googleapis.com/hostinger-horizons-assets-prod/dff470d7-425c-4712-a28b-1980c2756f20/cb412ae955dd4047fa80250181d778c1.png"
          alt="Cresen Ventures Logo"
          className="h-12 w-12"
        />
        <div ref={counterRef} className="text-5xl font-semibold font-mono">
          {counter}%
        </div>
      </div>
    </div>
  );
};

export default Preloader;