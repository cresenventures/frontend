import React, { useState, useEffect } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
  SheetDescription,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Minus, Plus, ShoppingCart, CreditCard, Loader2, Mail, KeyRound, AlertTriangle } from 'lucide-react';
import { useToast } from './ui/use-toast';

const RAZORPAY_KEY_ID = 'rzp_test_YOUR_KEY_ID';

const loadScript = (src) => {
  return new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

const CartSheet = ({ isOpen, setIsOpen, cart, updateQuantity, removeFromCart, clearCart }) => {
  const { toast } = useToast();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState('email'); // email, otp, address
  const [isProcessing, setIsProcessing] = useState(false);

  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [shippingDetails, setShippingDetails] = useState({ name: '', phone: '', address: '', city: '', pincode: '' });

  const totalBoxes = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.numericPrice * item.quantity, 0);
  const shippingCost = totalBoxes * 400;
  const grandTotal = subtotal + shippingCost;
  
  const isRazorpayConfigured = RAZORPAY_KEY_ID !== 'rzp_test_YOUR_KEY_ID';

  useEffect(() => {
    if (!isOpen && !isCheckoutOpen) {
      setCheckoutStep('email');
      setEmail('');
      setOtp('');
    }
  }, [isOpen, isCheckoutOpen]);

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        variant: "destructive",
        title: "Your cart is empty!",
        description: "Add some products to your cart before proceeding.",
      });
      return;
    }
    setIsOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleSendOtp = () => {
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      toast({ variant: 'destructive', title: 'Invalid Email', description: 'Please enter a valid email address.' });
      return;
    }
    setIsProcessing(true);
    toast({ title: 'OTP Sent!', description: 'A (simulated) OTP has been sent to your email.' });
    setTimeout(() => {
      setIsProcessing(false);
      setCheckoutStep('otp');
    }, 1000);
  };

  const handleVerifyOtp = () => {
    if (otp !== '123456') {
      toast({ variant: 'destructive', title: 'Invalid OTP', description: 'The entered OTP is incorrect. Please try again.' });
      return;
    }
    setIsProcessing(true);
    toast({ title: '✅ Email Verified!', description: 'You can now proceed to enter your shipping details.' });
    setTimeout(() => {
      setIsProcessing(false);
      setCheckoutStep('address');
    }, 1000);
  };

  const handleShippingChange = (e) => {
    const { id, value } = e.target;
    setShippingDetails(prev => ({ ...prev, [id]: value }));
  };

  const validateShippingForm = () => {
    for (const key in shippingDetails) {
      if (shippingDetails[key].trim() === '') {
        toast({ variant: 'destructive', title: 'Missing Information', description: `Please fill out the ${key} field.` });
        return false;
      }
    }
    if (shippingDetails.phone.length < 10) {
        toast({ variant: 'destructive', title: 'Invalid Phone Number', description: `Please enter a valid 10-digit phone number.` });
        return false;
    }
    return true;
  };

  const handleProceedToPayment = async () => {
    if (!validateShippingForm()) return;
    
    setIsProcessing(true);

    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js');
    if (!res) {
      toast({ variant: 'destructive', title: 'Payment Gateway Error', description: 'Could not load payment gateway. Please try again.' });
      setIsProcessing(false);
      return;
    }

    const options = {
      key: RAZORPAY_KEY_ID,
      amount: grandTotal * 100, // amount in the smallest currency unit
      currency: "INR",
      name: "Cresen Ventures",
      description: "Thermal Paper Rolls Order",
      image: "/logo.svg", // You can add a logo URL here
      handler: function (response) {
        toast({ title: '✅ Payment Successful!', description: `Payment ID: ${response.razorpay_payment_id}` });
        clearCart();
        setIsCheckoutOpen(false);
      },
      prefill: {
        name: shippingDetails.name,
        email: email,
        contact: shippingDetails.phone,
      },
      notes: {
        address: `${shippingDetails.address}, ${shippingDetails.city}, ${shippingDetails.pincode}`,
        cart: JSON.stringify(cart),
      },
      theme: {
        color: "#408BF2",
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.on('payment.failed', function (response) {
        toast({ variant: 'destructive', title: 'Payment Failed', description: response.error.description });
        setIsProcessing(false);
    });
    paymentObject.open();
  };

  const CartItem = ({ item }) => (
    <div className="flex items-center justify-between py-4">
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 bg-secondary rounded-lg flex-shrink-0"></div>
        <div>
          <h4 className="font-semibold">{item.title}</h4>
          <p className="text-sm text-muted-foreground">{item.quantity} x ₹{item.numericPrice.toFixed(2)}</p>
          <p className="font-bold text-primary">₹{(item.numericPrice * item.quantity).toFixed(2)}</p>
        </div>
      </div>
      <div className="flex items-center border rounded-lg">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.title, item.quantity - 1)}>
          <Minus className="w-4 h-4" />
        </Button>
        <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.title, item.quantity + 1)}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  return (
    <>
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent className="w-full md:max-w-md flex flex-col">
          <SheetHeader>
            <SheetTitle>Your Shopping Cart</SheetTitle>
            <SheetDescription>Review your items and proceed to checkout.</SheetDescription>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto -mx-6 px-6 divide-y">
            {cart.length > 0 ? (
              cart.map((item) => <CartItem key={item.id} item={item} />)
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <ShoppingCart className="w-16 h-16 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold">Your cart is empty</h3>
                <p className="text-muted-foreground">Add some products to get started!</p>
              </div>
            )}
          </div>
          {cart.length > 0 && (
            <SheetFooter className="mt-auto border-t pt-6 space-y-4">
                <div className="w-full space-y-2">
                    <div className="flex justify-between"><span>Subtotal</span><span>₹{subtotal.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span>Shipping ({totalBoxes} {totalBoxes > 1 ? 'boxes' : 'box'})</span><span>₹{shippingCost.toFixed(2)}</span></div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2"><span>Grand Total</span><span>₹{grandTotal.toFixed(2)}</span></div>
                </div>
                <Button size="lg" className="w-full" onClick={handleCheckout}>
                    Proceed to Checkout
                </Button>
            </SheetFooter>
          )}
        </SheetContent>
      </Sheet>

      <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <DialogContent className="sm:max-w-md">
          {checkoutStep === 'email' && (
            <>
              <DialogHeader>
                <DialogTitle>Step 1: Verify Your Email</DialogTitle>
                <DialogDescription>We'll send a one-time password to your email address.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <DialogFooter>
                <Button onClick={handleSendOtp} disabled={isProcessing} className="w-full">
                  {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
                  Send OTP
                </Button>
              </DialogFooter>
            </>
          )}
          {checkoutStep === 'otp' && (
            <>
              <DialogHeader>
                <DialogTitle>Step 2: Enter OTP</DialogTitle>
                <DialogDescription>Enter the 6-digit code sent to {email}. (Hint: it's 123456)</DialogDescription>
              </DialogHeader>
              <div className="flex justify-center py-4">
                <InputOTP maxLength={6} value={otp} onChange={(value) => setOtp(value)}>
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <DialogFooter>
                <Button onClick={handleVerifyOtp} disabled={isProcessing} className="w-full">
                  {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                  Verify OTP
                </Button>
              </DialogFooter>
            </>
          )}
          {checkoutStep === 'address' && (
            <>
              <DialogHeader>
                <DialogTitle>Step 3: Shipping Details</DialogTitle>
                <DialogDescription>Provide your address for delivery.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-3 py-4">
                <Label htmlFor="name">Full Name</Label><Input id="name" value={shippingDetails.name} onChange={handleShippingChange} />
                <Label htmlFor="phone">Phone Number</Label><Input id="phone" type="tel" value={shippingDetails.phone} onChange={handleShippingChange} />
                <Label htmlFor="address">Address</Label><Input id="address" value={shippingDetails.address} onChange={handleShippingChange} />
                <Label htmlFor="city">City</Label><Input id="city" value={shippingDetails.city} onChange={handleShippingChange} />
                <Label htmlFor="pincode">Pincode</Label><Input id="pincode" type="number" value={shippingDetails.pincode} onChange={handleShippingChange} />
              </div>
              <DialogFooter>
                {isRazorpayConfigured ? (
                  <Button onClick={handleProceedToPayment} disabled={isProcessing} className="w-full">
                    {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                    Proceed to Payment (₹{grandTotal.toFixed(2)})
                  </Button>
                ) : (
                  <div className="w-full text-center p-3 rounded-lg bg-destructive/10 text-destructive-foreground/90 border border-destructive/20 flex flex-col items-center gap-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5" />
                      <p className="font-semibold">Payments Not Enabled</p>
                    </div>
                    <p className="text-sm">Please provide a Razorpay Key ID to activate checkout.</p>
                  </div>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CartSheet;