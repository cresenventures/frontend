import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

const ContactInfoCard = ({ icon: Icon, title, description, buttonText, onClick }) => (
  <motion.div 
    className="bg-white p-6 rounded-lg border border-gray-200 transition-all duration-300 hover:border-primary/50 hover:shadow-lg"
    whileHover={{ y: -5 }}
  >
    <div className="flex items-center mb-4">
      <Icon className="w-8 h-8 text-primary mr-4" />
      <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    </div>
    <p className="text-gray-600 mb-4">{description}</p>
    <Button 
      onClick={onClick}
      className="bg-primary hover:bg-primary/90 text-primary-foreground w-full justify-start"
    >
      {buttonText}
    </Button>
  </motion.div>
);

const ContactSection = ({ handleCallNow, handleEmailContact, handleWhatsAppContact, showComingSoonToast }) => {
  const contactDetails = [
    { 
      icon: Phone, 
      title: "Phone", 
      description: "Call us for immediate assistance", 
      buttonText: "+91 9995742767", 
      onClick: handleCallNow,
    },
    { 
      icon: Mail, 
      title: "Email", 
      description: "Send us your requirements", 
      buttonText: "cresenventures@gmail.com", 
      onClick: handleEmailContact,
    },
    { 
      icon: MessageCircle, 
      title: "WhatsApp", 
      description: "Quick quotes and customization", 
      buttonText: "+91 79949 51831", 
      onClick: handleWhatsAppContact,
    }
  ];

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-on-scroll">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Get In <span className="text-primary">Touch</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to partner with us? Contact our team for quotes, customization, or any inquiries.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="animate-on-scroll space-y-6">
            {contactDetails.map((detail, index) => (
              <ContactInfoCard key={index} {...detail} />
            ))}
          </div>
          
          <motion.div
            className="animate-on-scroll bg-gray-50 p-8 rounded-lg border border-gray-200"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
          >
            <div className="flex items-center mb-6">
              <MapPin className="w-8 h-8 text-primary mr-4" />
              <h3 className="text-2xl font-bold text-gray-800">Our Location</h3>
            </div>
            
            <div className="space-y-3 text-gray-600">
              <p><span className="font-semibold text-gray-800">Building:</span> 51/2178, Gandhi Square Junction</p>
              <p><span className="font-semibold text-gray-800">Street:</span> Maradu Road</p>
              <p><span className="font-semibold text-gray-800">Landmark:</span> Near Mad Dog Tattoos</p>
              <p><span className="font-semibold text-gray-800">Area:</span> Poonithura, Maradu</p>
              <p><span className="font-semibold text-gray-800">City:</span> Ernakulam, Kerala</p>
              <p><span className="font-semibold text-gray-800">PIN:</span> 682038</p>
            </div>
            
            <Button 
              onClick={showComingSoonToast}
              className="mt-6 w-full bg-gray-300 hover:bg-gray-400 text-gray-800"
            >
              <MapPin className="w-4 h-4 mr-2" />
              View on Map
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;