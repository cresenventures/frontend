import React from 'react';
import { motion } from 'framer-motion';

const AboutSection = () => {
  return (
    <section id="about" className="py-24 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div
            className="animate-on-scroll"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              About <span className="text-primary">Cresen Ventures</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              A dynamic company specializing in thermal paper manufacturing, 
              serving global clients across multiple industries.
            </p>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Vision</h3>
                <p className="text-gray-600">
                  To be a globally recognized and trusted partner in thermal paper manufacturing, 
                  delivering innovative, reliable, and sustainable products that empower industries.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Mission</h3>
                <p className="text-gray-600">
                  To provide high-quality thermal paper products that exceed customer expectations 
                  in performance, reliability, and value through advanced production techniques 
                  and operational excellence.
                </p>
              </div>
            </div>
          </div>
          
          <div
            className="animate-on-scroll"
          >
            <img  
              className="rounded-xl shadow-lg w-full h-auto object-cover"
              alt="Bulk thermal paper rolls and packaging"
              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/dff470d7-425c-4712-a28b-1980c2756f20/b6cc9cb415f4b218c2add5ae7d0fefb3.jpg" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;