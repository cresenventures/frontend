import React from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, MessageCircle } from 'lucide-react';

const HeroSection = ({ handleWhatsAppContact }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background pt-20">
      <div className="container mx-auto px-6 text-center relative z-10">
        <h1 className="hero-title text-5xl md:text-7xl lg:text-8xl font-bold text-gray-900 mb-6 leading-tight">
          Precision in Every Roll
        </h1>
        
        <p className="hero-subtitle text-xl md:text-2xl text-gray-600 mb-10 max-w-4xl mx-auto">
          Globally recognized manufacturer delivering innovative, reliable, and sustainable 
          thermal paper products for diverse industries.
        </p>
        
        <div className="hero-buttons flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button 
            onClick={() => document.getElementById('products').scrollIntoView({ behavior: 'smooth' })}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Explore Products
          </Button>
          <Button 
            onClick={handleWhatsAppContact}
            variant="outline"
            className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Get Quote
          </Button>
        </div>

        <div className="hero-image mx-auto w-full max-w-4xl">
          <img 
            src="https://storage.googleapis.com/hostinger-horizons-assets-prod/dff470d7-425c-4712-a28b-1980c2756f20/c7d8a487327b9e473aa4ea27b1ec80d3.jpg" 
            alt="Premium Gold and Diamond thermal paper rolls" 
            className="mx-auto h-auto w-full rounded-lg shadow-2xl"
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;