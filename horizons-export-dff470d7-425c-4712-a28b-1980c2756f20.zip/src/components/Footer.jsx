import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/dff470d7-425c-4712-a28b-1980c2756f20/cb412ae955dd4047fa80250181d778c1.png" 
                alt="Cresen Ventures Logo" 
                className="h-10 w-10 bg-white rounded-full p-1"
              />
              <div>
                <span className="text-lg font-bold text-white">Cresen Ventures</span>
                <p className="text-xs text-gray-400">& Innovations</p>
              </div>
            </div>
            <p>
              Your trusted partner for premium thermal paper solutions worldwide.
            </p>
          </div>
          
          <div>
            <span className="text-lg font-bold text-white mb-4 block">Quick Links</span>
            <ul className="space-y-2">
              <li><a href="#products" className="hover:text-primary transition-colors">Products</a></li>
              <li><a href="#services" className="hover:text-primary transition-colors">Services</a></li>
              <li><a href="#about" className="hover:text-primary transition-colors">About Us</a></li>
              <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <span className="text-lg font-bold text-white mb-4 block">Contact Info</span>
            <ul className="space-y-2">
              <li>+91 9995742767</li>
              <li>cresenventures@gmail.com</li>
              <li>Maradu, Ernakulam, Kerala</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center text-gray-500">
          <p>
            © {new Date().getFullYear()} Cresen Ventures and Innovations. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;